/*
 * Scheduler.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef SCHEDULER_H_
#define SCHEDULER_H_
#include "Light.h"
#include "Temperature.h"
#include "Pression.h"
#include "Humidity.h"
#include "Serveur.h"

class Scheduler {
private:
public:
    Serveur sch_serveur;

    Light light;
    Pression pression;
    Temperature temperature;
    Humidity humidity;

    Scheduler();
    ~Scheduler();
    void dataTrans_P();
    void dataTrans_L();
    void dataTrans_H();
    void dataTrans_T();
    void trans();

};

#endif /* SCHEDULER_H_ */
