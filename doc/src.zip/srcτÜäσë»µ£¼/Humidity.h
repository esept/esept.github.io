/*
 * Humidity.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef HUMIDITY_H_
#define HUMIDITY_H_

#include "Sensor.h"

class Humidity :public Sensor{
private:
    int id;
public:
    Humidity();
    ~Humidity();

    int getID();
    float getData();

    virtual float aleaGenVal() override;
};

#endif /* HUMIDITY_H_ */
