/*
 * Sensor.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "Sensor.h"
#include "stdlib.h"
#include "unistd.h"
#include <iostream>
using namespace std;

Sensor::Sensor() {}

Sensor::~Sensor() {}

int Sensor::getData() {
    return aleaGenVal();
}

float Sensor::aleaGenVal(){
	return rand();
}
