/*
 * Light.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef LIGHT_H_
#define LIGHT_H_
#include "Sensor.h"


class Light : public Sensor{
private:
    int id;

public:
    Light();
    ~Light();

    int getID();
    bool getData();

    virtual float aleaGenVal() override;
};

#endif /* LIGHT_H_ */
