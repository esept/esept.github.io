/*
 * Serveur.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "Serveur.h"
#include "string"
#include "fstream"
#include "iostream"
using namespace std;

Serveur::Serveur() {
	this->consolActivation = true;
	this->logActivation = true;
}
Serveur::~Serveur() {}
Serveur::Serveur(const Serveur& serveur){

	this->consolActivation = serveur.consolActivation;
	this->logActivation = serveur.logActivation;
}
void Serveur::changeAct(bool con,bool log){
	this->logActivation = log;
	this->consolActivation = con;
}

