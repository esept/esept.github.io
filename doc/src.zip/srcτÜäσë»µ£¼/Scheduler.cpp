/*
 * Scheduler.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "Scheduler.h"
#include "unistd.h"
#include "iostream"
#include <time.h>
using namespace std;

Scheduler::Scheduler() {}

Scheduler::~Scheduler() {}

void Scheduler::dataTrans_P() {
    sch_serveur.dataRcv<>(pression.getData(),pression.getID());
}
void Scheduler::dataTrans_L() {
    sch_serveur.dataRcv<bool>(light.getData(),light.getID());
}
void Scheduler::dataTrans_H() {
    sch_serveur.dataRcv<float>(humidity.getData(),humidity.getID());
}
void Scheduler::dataTrans_T() {
    sch_serveur.dataRcv<float>(temperature.getData(),temperature.getID());
}


void Scheduler::trans() {
    time_t start;
    start = time(0);
    while(1){
        cout << "-----" << time(0)-start+1 << "-----Second----- " << endl;
        if((time(0)-start)%2 == 0){
            this->dataTrans_H();
        }
        if((time(0)-start)%3 == 0){
            this->dataTrans_L();
        }
        if((time(0)-start)%5 == 0){
            this->dataTrans_T();
        }
        if((time(0)-start)%4 == 0){
            this->dataTrans_P();
        }
        sleep(1);
    }

    cout << "FIN " << time(0)-start << endl;
}
