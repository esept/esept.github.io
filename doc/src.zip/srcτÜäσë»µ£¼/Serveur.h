/*
 * Serveur.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef SERVEUR_H_
#define SERVEUR_H_
#include "string"
#include "iostream"
#include "fstream"
using namespace std;

class Serveur {
private:
	bool consolActivation;
	bool logActivation;
public:
	Serveur();
	virtual ~Serveur();
	Serveur(const Serveur& serveur);

	void changeAct(bool con,bool log);

	template <class T>
	void fileWrite(T i,int id){
		string f;
		switch(id){
				case 1:f = "Temperature.txt"; break;
				case 2:f = "Pression.txt"; break;
				case 3:f = "Humidity.txt"; break;
				case 4:f = "Light.txt"; break;
			}
		ofstream File(f,ios::app);
		File << "\n" << i ;
		File.close();
	}

	template <class T>
	void consolWrite(T i,int id){
		string f;
		switch (id) {
				case 1: f = "Temperature	";  break;
				case 2: f = "Pression 	";     break;
				case 3: f = "Humidity 	";     break;
				case 4: f = "Light 		";        break;
			}
			cout << f << " " << i << endl;
	}

	template <class T>
	void dataRcv(T data,int id){
		if(consolActivation){
			this->consolWrite(data,id);
		}
		if(logActivation){
			this->fileWrite(data,id);
		}
	}

};

#endif /* SERVEUR_H_ */
