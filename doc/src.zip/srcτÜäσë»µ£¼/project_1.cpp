//============================================================================
// Name        : project_1.cpp
// Author      : XU
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Scheduler.h"
using namespace std;

int main() {
	cout << " ===Start   Test===" << endl;

    Scheduler scheduler;
    scheduler.sch_serveur.changeAct(true, true);
    // activate ou pas "write" sur log/consol

    scheduler.trans();
    // commencer de transfer les data
    // fonctionne toujours

	return 0;
}
