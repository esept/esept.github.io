/*
 * Pression.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef PRESSION_H_
#define PRESSION_H_

# include "Sensor.h"

class Pression : public Sensor{
private:
    int id;
public:
    Pression();
    ~Pression();

    int getID();
    int getData();

    virtual float aleaGenVal() override;
};
#endif /* PRESSION_H_ */
