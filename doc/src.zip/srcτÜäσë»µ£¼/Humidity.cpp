/*
 * Humidity.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "fstream"
#include "Humidity.h"
#include "stdlib.h"
#include <iostream>
using namespace std;
Humidity::Humidity() {
    this->id = 3;

    std::ofstream File;
    File.open("Humidity.txt");
    File << "log Humidity" ;
    File.close();
}

Humidity::~Humidity() {}

int Humidity::getID() {
    return this->id;
}

float Humidity::getData() {
//	float f =
	return this->aleaGenVal();
}

float Humidity::aleaGenVal(){
//	int a = ();
	return (rand() % (65-45+1))+ 45+rand() / double(RAND_MAX);
}
