/*
 * Temperature.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_
#include "Sensor.h"

class Temperature : public Sensor{
private:
    int id;
public:
    Temperature();
    ~Temperature();

    int getID();
    float getData();

    virtual float aleaGenVal() override;
};

#endif /* TEMPERATURE_H_ */
