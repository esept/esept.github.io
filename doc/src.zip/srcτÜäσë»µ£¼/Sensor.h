/*
 * Sensor.h
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#ifndef SENSOR_H_
#define SENSOR_H_

class Sensor {
private:
//	int temps = 1;

public:
	Sensor();
	virtual ~Sensor();

	int getData();
protected:
	virtual float aleaGenVal();
};

#endif /* SENSOR_H_ */
