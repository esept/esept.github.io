/*
 * Temperature.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "Temperature.h"
#include "fstream"

Temperature::Temperature() {
    this->id = 1 ;
    std::ofstream File;
    File.open("Temperature.txt");
    File << "log Temperature" ;
    File.close();
}

Temperature::~Temperature() {}

int Temperature::getID() {
    return id;
}

float Temperature::getData() {
	return this->aleaGenVal();
}

float Temperature::aleaGenVal(){
	return (rand() % (42-34+1))+ 34+rand() / double(RAND_MAX);
}
