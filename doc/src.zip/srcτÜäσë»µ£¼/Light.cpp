/*
 * Light.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "Light.h"
#include "fstream"
#include "stdlib.h"
#include <iostream>
using namespace std;

Light::Light() {
    this->id = 4;
//    this->temps = 1;

    std::ofstream File;
    File.open("Light.txt");
    File << "log Light" ;
    File.close();
}

Light::~Light() {}

int Light::getID() {
    return this->id;
}

bool Light::getData() {
    int data = this->aleaGenVal();
    if(data) return true;
    else return false;
}

float Light::aleaGenVal(){
	int a = rand()%2;
	return a;
}
