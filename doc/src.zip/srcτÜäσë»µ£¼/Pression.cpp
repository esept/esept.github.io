/*
 * Pression.cpp
 *
 *  Created on: 2021年10月2日
 *      Author: xuzy
 */

#include "Pression.h"
#include "fstream"
#include "stdlib.h"

Pression::Pression() {
    this->id = 2 ;

    std::ofstream File;
    File.open("Pression.txt");
    File << "log Pression" ;
    File.close();
}

Pression::~Pression() {}


int Pression::getID() {
    return this->id;
}

int Pression::getData() {
    return int(this->aleaGenVal());
}

float Pression::aleaGenVal(){
	return rand()%18;
}
